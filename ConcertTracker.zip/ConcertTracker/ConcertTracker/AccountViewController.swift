//
//  AccountViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 13/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit

class AccountViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var DateOfBirth: UIDatePicker!
    
    @IBOutlet weak var btnSaveOutlet: UIButton!
    @IBOutlet weak var lblSucces: UILabel!
    @IBOutlet weak var lblAchtergrond: UILabel!
    
    @IBOutlet weak var photoImageView: UIImageView!
    
    var userName:String = ""
    let defaults = UserDefaults.standard
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtFirstName.delegate = self
        txtLastName.delegate = self
        txtEmail.delegate = self
        
        
        DateOfBirth.addTarget(self, action: #selector(DateOfBirthChanged(_:)), for: .valueChanged)

        btnSaveOutlet.isEnabled = false
        btnSaveOutlet.backgroundColor = UIColor.gray
        
        // Do any additional setup after loading the view.
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        // Dismiss the picker if the user canceled.
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        // The info dictionary may contain multiple representations of the image. You want to use the original.
        guard let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        
        // Set photoImageView to display the selected image.
        photoImageView.image = selectedImage
        let imageData: Data = UIImagePNGRepresentation(selectedImage)!
        print("de foto is: \((imageData))")
        let imgData = UIImageJPEGRepresentation(selectedImage, 1)!
        print("de andere foto is: \(imgData)")
        
        // Dismiss the picker.
        dismiss(animated: true, completion: nil)
    }
    
    //Selecteer een foto uit uw foto's
    @IBAction func selectImageFromPhotoLibrary(_ sender: UITapGestureRecognizer) {

        
        // UIImagePickerController is a view controller that lets a user pick media from their photo library.
        let imagePickerController = UIImagePickerController()
        
        // Only allow photos to be picked, not taken.
        imagePickerController.sourceType = .photoLibrary
        
        // Make sure ViewController is notified when the user picks an image.
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
    }
    
    //standaard textfield methode om te bepalen wat er moet gebeuren als je op de knop rechts onderaan klikt
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        if textField == txtFirstName { // Switch focus to other text field
            txtLastName.becomeFirstResponder()
        }
        if textField == txtLastName { // Switch focus to other text field
            txtEmail.becomeFirstResponder()
        }
        return true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        haalDataOp()
        //haalAchtergrondOp()
        themaKleur()
        
    }
    
    //hier haal ik de user data op
    func haalDataOp() {
        let url = URL(string: "https://concerttracker.aenterprise.info/session.php")
        
        let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!)
            print("data:")
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any] {
                    print("try")
                    print(json)
                    let voornaam = json["Voornaam"] as? String
                    let familienaam = json["Familienaam"] as? String
                    let email = json["Email"] as? String
                    let geboortedatum = json["Geboortedatum"] as? String
                    self.userName = (json["username"] as? String)!
                    let isoDate = geboortedatum
                    
                    
                    
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    if isoDate != nil {
                        let date = dateFormatter.date(from:(isoDate)!)
                        let calendar = Calendar.current
                        let components = calendar.dateComponents([.year, .month, .day], from: date!)
                        let finalDate = calendar.date(from:components)
                        
                        OperationQueue.main.addOperation {
                            self.txtFirstName.text = voornaam
                            self.txtLastName.text = familienaam
                            self.txtEmail.text = email
                            self.DateOfBirth.date = finalDate!
                            
                        }
                    }
                    else
                    {
                        OperationQueue.main.addOperation {
                            self.txtFirstName.text = voornaam
                            self.txtLastName.text = familienaam
                            self.txtEmail.text = email
                            
                        }
                    }
                }
            } catch let error {
                print(error.localizedDescription)
            }
            
        }
        
        task.resume()
    }
    
    //gebruik ik NIET meer
    func haalAchtergrondOp() {
        let url = URL(string: "https://concerttracker.aenterprise.info/session.php")
        
        let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!)
            print("data:")
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any] {
                    print("try")
                    print(json)
                    
                    self.userName = (json["username"] as? String)!
                    print("Username is: \(self.userName)")
                    
                    if (json["Thema"] as? String == "blue")
                    {
                        DispatchQueue.main.async {
                            
                            
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "orange")
                    {
                        DispatchQueue.main.async {
                            
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "green")
                    {
                        DispatchQueue.main.async {
                            
                            
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
                        }
                        
                    }
                    
                }
            } catch let error {
                print(error.localizedDescription)
            }
            
        }
        
        task.resume()
    }
    
    //haal de themakleur uit de Userdefaults
    func themaKleur() {
        let kleur = defaults.string(forKey: "Thema")
        print("Userdef kleur is: \(String(describing: kleur))")
        if kleur == "blue"
        {
            DispatchQueue.main.async {
                
                self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
            }
        }
        if kleur == "orange"
        {
            DispatchQueue.main.async {
                
                self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
            }
        }
        if kleur == "green"
        {
            DispatchQueue.main.async {
                
                self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
            }
            
        }
    }
    
    //Alle methodes om de save button te enabelen als je iets verandert
    @IBAction func DateOfBirthChanged(_ sender: Any) {
        btnSaveOutlet.isEnabled = true
        btnSaveOutlet.backgroundColor = UIColor(red: 20/255, green: 159/255, blue: 255/255, alpha: 1)
    }
    
    @IBAction func txtEmailChanged(_ sender: Any) {
        btnSaveOutlet.isEnabled = true
        btnSaveOutlet.backgroundColor = UIColor(red: 20/255, green: 159/255, blue: 255/255, alpha: 1)
    }
    @IBAction func txtLastNameChanged(_ sender: Any) {
        btnSaveOutlet.isEnabled = true
        btnSaveOutlet.backgroundColor = UIColor(red: 20/255, green: 159/255, blue: 255/255, alpha: 1)
    }
    
    @IBAction func txtUsernameChanged(_ sender: Any) {
        btnSaveOutlet.isEnabled = true
        btnSaveOutlet.backgroundColor = UIColor(red: 20/255, green: 159/255, blue: 255/255, alpha: 1)
    }

    //Sla de gegevens op in de database
    @IBAction func btnSave(_ sender: Any) {
        let myUrl = URL(string: "https://concerttracker.aenterprise.info/Account.php");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"// Compose a query string
        //request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        print("username\(userName)")
        
        let date = DateOfBirth.date
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from:date)

        
        let postString = "User=\(userName)&Voornaam=\(txtFirstName.text!)&Familienaam=\(txtLastName.text!)&Email=\(txtEmail.text!)&Geboortedatum=\(dateString)"
        print(postString)
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
        
            if error != nil
            {
                print("error=\(String(describing: error))")
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "No internet connection available, please try again", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
                return
            }
            else
            {
                DispatchQueue.main.async {
                    self.lblSucces.text = "Your account information has been changed succesfully"
                    self.btnSaveOutlet.isEnabled = false
                    self.btnSaveOutlet.backgroundColor = UIColor.gray
                }
                
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print(parseJSON)

                }
            } catch let error {
                print("Error: ")
                print(error)
                
            }
        }
        task.resume()
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
