//
//  ViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 25/11/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITextFieldDelegate {
    
    let url = "https://concerttracker.aenterprise.info/login.php"
    
    @IBOutlet weak var imgCT: UIImageView!
    
    @IBOutlet weak var rememberMeSwitch: UISwitch!
    @IBOutlet weak var btnCreateOutlet: UIButton!
    @IBOutlet weak var lblTitel: UILabel!
    @IBOutlet weak var textfieldUsername: UITextField!
    @IBOutlet weak var textfieldPassword: UITextField!
    @IBOutlet weak var lblError: UILabel!
    @IBOutlet weak var lblRememberMe: UILabel!
    @IBOutlet weak var btnLoginOutlet: UIButton!
    @IBOutlet weak var lblRegister: UILabel!
    @IBOutlet weak var btnRegister: UIButton!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblPassword: UILabel!
    @IBOutlet weak var activitySpin: UIActivityIndicatorView!
    
    var activityIndicator:UIActivityIndicatorView = UIActivityIndicatorView()
    var teller = 0

    //Functie als je op de knop 'Login' klikt
    @IBAction func buttonSave(_ sender: UIButton) {
        LogIn()
    }
    
    //De animatie die je ziet als je op de 'Login' knop klikt
    @objc func addPulse(){
        let pulse = Pulsing(numberOfPulses: 1, radius: 110, position: btnLoginOutlet.center)
        pulse.animationDuration = 0.8
        pulse.backgroundColor = UIColor.blue.cgColor
        
        self.view.layer.insertSublayer(pulse, below: btnLoginOutlet.layer)
        LogIn()
        
        
    }
    //De methode om in te loggen
    func LogIn() {
        lblError.text = ""
        activitySpin.isHidden = false
        activitySpin.startAnimating()
        let myUrl = URL(string: "https://concerttracker.aenterprise.info/login.php");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"
        
        let postString = "username=\(textfieldUsername.text!)&password=\(textfieldPassword.text!)"
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                DispatchQueue.main.async {
                    self.activitySpin.isHidden = true
                    self.activitySpin.stopAnimating()
                }
                
                print("error=\(String(describing: error))")
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "No internet connection available, please try again", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
                self.activitySpin.isHidden = true
                self.activitySpin.stopAnimating()
                return
            }

            print("response = \(String(describing: response))")

            do { 
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print(parseJSON)
                    
                    let usernameValue = parseJSON["loggedin"] as? String
                    print("username: \(String(describing: usernameValue))")

                    if usernameValue != nil
                    {
                        DispatchQueue.main.async {  //HIER SLA IK DE USERNAME EN PASSWORD LOKAAL OP IN EEN DATABASE (En ja, het is veilig ;) )
                            
                            let appDelegate = UIApplication.shared.delegate as! AppDelegate
                            
                            let context = appDelegate.persistentContainer.viewContext
                            //Hier delete ik de vorige username en password
                            let ReqVar = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
                            let DelAllReqVar = NSBatchDeleteRequest(fetchRequest: ReqVar)
                            do { try context.execute(DelAllReqVar) }
                            catch { print(error) }
                            
                            //Hier zet ik een nieuwe username en password in de lokale database
                            let newUser = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context)
                            
                            print("Switch: \((newUser.value(forKey: "password") != nil))")
                            newUser.setValue(self.textfieldUsername.text, forKey: "username")
                            newUser.setValue(self.textfieldPassword.text, forKey: "password")
                            
                            if self.rememberMeSwitch.isOn == true
                            {
                                //self.rememberMeSwitch.setOn(false, animated: true)
                                newUser.setValue("true", forKey: "switchRememberMe")
                            }
                            else
                            {
                                //self.rememberMeSwitch.setOn(true, animated: true)
                                newUser.setValue("false", forKey: "switchRememberMe")
                            }
                            
                            do {
                                try context.save()
                            } catch {
                                print("Failed saving")
                            }
 
                            
                        }

                        OperationQueue.main.addOperation {

                            sleep(1)
                            self.performSegue(withIdentifier: "gaNaarIndex", sender: self)
                        }
                        print("ok")
                    }
                    else
                    {
                        DispatchQueue.main.async {
                            
                            self.lblError.text = "Your username or password is invalid!"
                            
                        }
                    }
                    //self.stopLoad()
                    DispatchQueue.main.async {
                        self.activitySpin.isHidden = true
                        self.activitySpin.stopAnimating()
                    }
              }
            } catch let error {
                print("Error: ")
                print(error)
                
            }
        }
        task.resume()
    }
    
    func load() {
        DispatchQueue.main.async {
            
            self.activityIndicator.center = self.view.center
            self.self.activityIndicator.hidesWhenStopped = true
            self.activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
            self.view.addSubview(self.activityIndicator)
        }
        
    }
    func stopLoad() {
        DispatchQueue.main.async {
            self.activityIndicator.stopAnimating()
        }
        
    }
    //Standaardfunctie die je nodig hebt voor textfields
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        if textField == textfieldUsername { // Switch focus to other text field
            textfieldPassword.becomeFirstResponder()
        }
        if textField == textfieldPassword {
            //LogIn()
        }
        return true
    }
    //Vul de username en password automatisch in als je de switch 'remember me' hebt aangezet.
    func LoadUserInfo()  {

            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            let context = appDelegate.persistentContainer.viewContext
            
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
            
            request.returnsObjectsAsFaults = false
            
            do {
                let result = try context.fetch(request)
                for data in result as! [NSManagedObject] {
                    print(data.value(forKey: "username") as! String)
                    
                    if (data.value(forKey: "switchRememberMe") as? String) == "true"
                        {
                        textfieldUsername.text = data.value(forKey: "username") as? String
                        textfieldPassword.text = data.value(forKey: "password") as? String
                        rememberMeSwitch.setOn((((data.value(forKey: "switchRememberMe") as? String) != nil)), animated: true)
                    }
                    else
                    {
                        rememberMeSwitch.setOn(false, animated: true)
                    }
                    
                    //LogIn()
                }
                
            } catch {
                
                print("Failed")
            }
    }
    override func viewWillAppear(_ animated: Bool) {
        LoadUserInfo()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textfieldUsername.delegate = self
        textfieldPassword.delegate = self
        lblRememberMe.layer.masksToBounds = true
        lblRememberMe.layer.cornerRadius = 5
        btnLoginOutlet.layer.masksToBounds = true
        btnLoginOutlet.layer.cornerRadius = 5
        btnCreateOutlet.layer.borderWidth = 0.5
        btnCreateOutlet.layer.borderColor = UIColor.blue.cgColor
        btnCreateOutlet.layer.cornerRadius = 5
        
        activitySpin.isHidden = true
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.addPulse))
        tapGestureRecognizer.numberOfTapsRequired = 1
        btnLoginOutlet.addGestureRecognizer(tapGestureRecognizer)
    }
}

