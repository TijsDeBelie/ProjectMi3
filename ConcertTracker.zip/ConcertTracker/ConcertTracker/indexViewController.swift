//
//  indexViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 28/11/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit
import Instructions
import Alamofire
import AlamofireImage
import SwiftyJSON
import SwiftSpinner
import SDWebImage

var alleName = [String]()
var alleDates = [String]()
var alleFotosVanEvents = [String]()
var alleInfoVanEvents = [String]()
var alleGenresVanEvents = [String]()
var allePlacesVanEvents = [String]()
var allePlaces = [String]()
var alleLatituden = [String]()
var alleLongituden = [String]()
var alleLocalTimeStart = [String]()
var alleLocalTimeEnd = [String]()
var alleEndDates = [String]()
var alleUrlVanEvents = [String]()
var allePricesvanEvents = [String]()
var myIndex = 0
var currentCountryCode = ""
let locale = Locale.current
var userNameInApp = ""


class indexViewController: UIViewController, CoachMarksControllerDataSource, CoachMarksControllerDelegate, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate {
    
    
    @IBOutlet weak var testView: UIView!
    @IBOutlet weak var btnHome: UIBarButtonItem!
    @IBOutlet weak var btnLogout: UIBarButtonItem!
    @IBOutlet weak var btnAbout: UIBarButtonItem!
    @IBOutlet weak var btnSearch: UIButton!
    @IBOutlet weak var btnSettings: UIBarButtonItem!
    @IBOutlet weak var LogoutView: UIView!
    @IBOutlet weak var AboutView: UIView!
    @IBOutlet weak var SettingsView: UIView!
    @IBOutlet weak var lblWelcomeBack: UILabel!
    @IBOutlet weak var txtSearchByName: UITextField!
    @IBOutlet weak var lblCurrentLocation: UILabel!
    @IBOutlet weak var switchCurrentLocation: UISwitch!
    
    
    var names = [String]()
    var teller = 0;
    let defaults = UserDefaults.standard
    var username: String = ""
    let coachMarksController = CoachMarksController()
    var lijstMetNamen = [Events]()
    
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alleName.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex = indexPath.row
        performSegue(withIdentifier: "toonEventInfo", sender: self)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        
        let (events) = alleName [indexPath.row]
        let (datums) = alleDates [indexPath.row]
        let (fotos) = alleFotosVanEvents [indexPath.row]
        
        //let url = URL(string: fotos)
        
        //cell.selectionStyle = .none
        
        //let data = try? Data(contentsOf: url!)
        
        //cell.imageView?.image = imageWithImage(image: UIImage(data: (data)!)!, scaledToSize: CGSize(width: 80, height: 50))
        cell.imageView?.sd_setImage(with: URL(string: fotos), placeholderImage: UIImage(named: "no_Image_Available.png"))
        let afbeelding = cell.imageView?.image
        cell.imageView?.image = imageWithImage(image: afbeelding!, scaledToSize: CGSize(width: 95, height: 55))
        cell.imageView?.layer.cornerRadius = 5
        cell.imageView?.layer.masksToBounds = true
        cell.textLabel?.text = events
        cell.detailTextLabel?.text = datums
        SwiftSpinner.hide()
        return cell
        
    }
    
    func imageWithImage(image:UIImage,scaledToSize newSize:CGSize)->UIImage{
        
        UIGraphicsBeginImageContext( newSize )
        image.draw(in: CGRect(x: 0,y: 0,width: newSize.width,height: newSize.height))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!.withRenderingMode(.alwaysOriginal)
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    struct Events {
        let name : String
    }
    
    
    
    @IBOutlet weak var lblEvents: UILabel!
    
    @IBOutlet weak var tableview: UITableView! {
        didSet {
            tableview.dataSource = self
        }
    }
    
    //Bepaal hoeveel tutorial 'stappen' je ondersteunt.
    func numberOfCoachMarks(for coachMarksController: CoachMarksController) -> Int {
        return 5
    }
    
    //waar de tutorialstap moet staan
    func coachMarksController(_ coachMarksController: CoachMarksController, constraintsForSkipView skipView: UIView, inParentView parentView: UIView) -> [NSLayoutConstraint]?
    {
        let constH:NSLayoutConstraint = NSLayoutConstraint(item: skipView, attribute: NSLayoutAttribute.height, relatedBy: NSLayoutRelation.equal, toItem: parentView, attribute:  NSLayoutAttribute.centerY, multiplier: 1, constant: 200);
        return [constH]
    }
    
    //Bepaal de tekst van een tutorialstap
    func coachMarksController(_ coachMarksController: CoachMarksController, coachMarkViewsAt index: Int, madeFrom coachMark: CoachMark) -> (bodyView: CoachMarkBodyView, arrowView: CoachMarkArrowView?) {
        let coachViews = coachMarksController.helper.makeDefaultCoachViews(withArrow: true, arrowOrientation: coachMark.arrowOrientation)
        
        switch(index) {
            
        case 0:
            coachViews.bodyView.hintLabel.text = "Go back to the Home page"
            coachViews.bodyView.nextLabel.text = "Ok"
        case 1:
            coachViews.bodyView.hintLabel.text = "Click here to log out"
            coachViews.bodyView.nextLabel.text = "Ok"
        case 2:
            coachViews.bodyView.hintLabel.text = "About us"
            coachViews.bodyView.nextLabel.text = "Ok"
        case 3:
            coachViews.bodyView.hintLabel.text = "Search for events"
            coachViews.bodyView.nextLabel.text = "Ok"
        case 4:
            coachViews.bodyView.hintLabel.text = "Click here to change the settings"
            coachViews.bodyView.nextLabel.text = "Ok"
        default: break
        }
        
        return (bodyView: coachViews.bodyView, arrowView: coachViews.arrowView)
    }
    
    
    let pointOfInterest = UIView()
    //Kies waarop de tutorial focust per stap
    func coachMarksController(_ coachMarksController: CoachMarksController, coachMarkAt index: Int) -> CoachMark {
        switch(index) {
        
        case 0:
            let btnHomeView = btnHome.value(forKey: "view") as? UIView  //BELANGRIJK
            var coachMark = coachMarksController.helper.makeCoachMark(for: btnHomeView)

            coachMark.disableOverlayTap = true
            coachMark.allowTouchInsideCutoutPath = false
            
            return coachMark
        case 1:
            let btnLogoutView = btnLogout.value(forKey: "view") as? UIView
            var coachMark = coachMarksController.helper.makeCoachMark(for: btnLogoutView)

            coachMark.disableOverlayTap = true
            coachMark.allowTouchInsideCutoutPath = false
            
            return coachMark
        case 2:
            let btnAboutView = btnAbout.value(forKey: "view") as? UIView
            var coachMark = coachMarksController.helper.makeCoachMark(for: btnAboutView)

            coachMark.disableOverlayTap = true
            coachMark.allowTouchInsideCutoutPath = false
            return coachMark
            
        case 3:
            
            var coachMark = coachMarksController.helper.makeCoachMark(for: self.btnSearch)
            
            coachMark.disableOverlayTap = true
            coachMark.allowTouchInsideCutoutPath = false
            
            return coachMark
        case 4:
            let btnSettingsView = btnSettings.value(forKey: "view") as? UIView
            var coachMark = coachMarksController.helper.makeCoachMark(for: btnSettingsView)

            coachMark.disableOverlayTap = true
            coachMark.allowTouchInsideCutoutPath = false
            
            return coachMark
        default:
            return coachMarksController.helper.makeCoachMark()
        }
        
    }

    override func viewDidLoad() {
        
        super.viewDidLoad()
        checkSession()
        //dataImageView.isHidden = true
        self.tableview.dataSource = self
        self.tableview.delegate = self
        txtSearchByName.delegate = self
        //btnSearch.layer.borderWidth = 2
        btnSearch.layer.cornerRadius = 5
        //btnSearch.layer.borderColor = UIColor.blue.cgColor
        let locale = Locale.current
        print("uw plaats is: \(locale.regionCode!)")
        lblCurrentLocation.text = "  Search by current location (\(locale.regionCode!)):"
        
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.coachMarksController.start(on: self)
    }
    
    //Kijk of je een tutorial moet tonen of niet
    override func viewWillAppear(_ animated: Bool) {
        themaKleur()
        if defaults.value(forKey: "Tutorial") as? String != "nee"
        {
            
            self.coachMarksController.dataSource = self
            
            let skipView = CoachMarkSkipDefaultView()
            
            skipView.setTitle("Skip", for: .normal)
            
            self.coachMarksController.skipView = skipView
            self.coachMarksController.overlay.color = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 0.5)
            
            defaults.set("nee", forKey: "Tutorial")
        }
        else
        {
            if defaults.value(forKey: "TutAdmin") as? String == "ja"
            {
                self.coachMarksController.dataSource = self
                
                let skipView = CoachMarkSkipDefaultView()
                
                skipView.setTitle("Skip", for: .normal)
                
                self.coachMarksController.skipView = skipView
                self.coachMarksController.overlay.color = UIColor(red: 0.2, green: 0.2, blue: 0.2, alpha: 0.5)
            }
            else
            {
                self.coachMarksController.dataSource = nil
                print("Geen Admin Tutorial voor u")
            }
            //defaults.set("nee", forKey: "TutAdmin")
        }
        
    }
    
   
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.coachMarksController.stop(immediately: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func themaKleur() {
        let kleur = defaults.string(forKey: "Thema")
        print("Userdef kleur is: \(String(describing: kleur))")
        if kleur == "blue"
        {
            DispatchQueue.main.async {
                self.btnSearch.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
            }
        }
        if kleur == "orange"
        {
            DispatchQueue.main.async {
                self.btnSearch.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
            }
        }
        if kleur == "green"
        {
            DispatchQueue.main.async {
                self.btnSearch.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
            }
            
        }
    }

    //Haal de session op
    func checkSession() {
        
        let url = URL(string: "https://concerttracker.aenterprise.info/session.php")
        
        let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!)
            print("data:")
            do {
                
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any] {
                    print("try")
                    print(json)
                    self.defaults.setValue(true, forKey: "isUserLoggedIn")
                    let success = json["username"] as? String
                    self.username = success!
                    userNameInApp = success!
                    let thema = json["Thema"] as? String
                    self.defaults.setValue(thema, forKey: "Thema")
                    self.defaults.setValue(success, forKey: "Username")
                    self.defaults.setValue("true", forKey: "btnGetLarger")
                    if json["admin"] as? Bool == true
                    {
                    self.defaults.set(true, forKey: "Admin")
                        print("dit is een admin")
                    }
                    else
                    {
                        self.defaults.set(false, forKey: "Admin")
                        print("dit is geen admin")
                    }
                    print("De username is: \(success!)")
                    print("Voornaam test\(String(describing: success))")
                    OperationQueue.main.addOperation {
                        if self.defaults.string(forKey: "First") == "false"
                        {
                        self.lblWelcomeBack.text = "Welcome back \(success ?? "")!"
                        }
                        else
                        {
                            self.lblWelcomeBack.text = "Welcome \(success ?? "")!"
                            self.defaults.setValue("false", forKey: "First")
                        }
                    }
                }
            } catch let error {
                print(error.localizedDescription)
            }
        }
        
        task.resume()
    }
    
    //Toon de foto als je op de knop 'search' klikt
    func toonSearch() {
        //dataImageView.isHidden = false
    }
    
    @IBAction func switchCurrentLocationChanged(_ sender: Any) {
        if switchCurrentLocation.isOn
        {
            currentCountryCode = "\(locale.regionCode!))"
        }
        else
        {
            currentCountryCode = ""
        }
    }
    
   
    func searchEvents() {
        txtSearchByName.resignFirstResponder()
        lijstMetNamen.removeAll()
        alleName.removeAll()
        alleDates.removeAll()
        alleFotosVanEvents.removeAll()
        allePlaces.removeAll()
        alleLatituden.removeAll()
        alleLongituden.removeAll()
        alleInfoVanEvents.removeAll()
        alleGenresVanEvents.removeAll()
        allePlacesVanEvents.removeAll()
        alleLocalTimeStart.removeAll()
        alleEndDates.removeAll()
        alleLocalTimeEnd.removeAll()
        alleUrlVanEvents.removeAll()
        allePricesvanEvents.removeAll()
        
        SwiftSpinner.show("Loading events from the server...") //&keyword=Gras
        let zoekresultatenName = txtSearchByName.text!
        let nieuweZoekResultaten = zoekresultatenName.replacingOccurrences(of: " ", with: "%20")
        print("de zoeker: https://app.ticketmaster.com/discovery/v2/events.json?&classificationName=music&sort=date,asc&&radius=100&countryCode=\(currentCountryCode)&apikey=91266liFMYink0pu2zFqYCT9yQ3zOYHT&keyword=\(nieuweZoekResultaten)")
        let code = currentCountryCode.replacingOccurrences(of: ")", with: "")
        
        print("code zoeker: \(code)")
        
        Alamofire.request("https://app.ticketmaster.com/discovery/v2/events.json?&classificationName=music&sort=date,asc&&radius=100&countryCode=\(code)&apikey=91266liFMYink0pu2zFqYCT9yQ3zOYHT&keyword=\(nieuweZoekResultaten)", parameters: ["query": "pages"]).responseJSON { response in
            print("zoek: \(self.txtSearchByName.text!)")
            
            switch (response.result) {
            case .success:
                if let values = response.result.value as? [String: AnyObject] {
                    
                    let json = JSON(values)
                    
                    // Returns null
                    print("otherJSON: \(json["_embedded"]["events"][0]["name"])")
                    
                    let pages = json["_embedded"]["events"]
                    for (_,page) in pages {
                        print(page["name"])
                        
                        let infoVanEvent = page["info"].string
                        if (infoVanEvent != nil)
                        {
                            alleInfoVanEvents.append(infoVanEvent!)
                        }
                        else{
                            alleInfoVanEvents.append("")
                        }
                        
                        alleUrlVanEvents.append(page["url"].string!)
                        let events = Events(name: page["name"].string!)
                        self.lijstMetNamen.append(events)
                        alleName.append(page["name"].string!)
                        //self.lblEvents.text = self.alleName as? String
                    }
                    print("alle info is: \(alleInfoVanEvents)")
                    
                    
                    let places = json["_embedded"]["events"]
                    for (_,page) in places {
                        
                        
                        let plaatsen = page["_embedded"]["venues"][0]["city"]["name"].string
                        if (plaatsen != nil)
                        {
                        allePlaces.append(plaatsen!)
                        }
                        else
                        {
                            allePlaces.append("")
                        }
                        
                    }
                    
                    
                    print("de plaatsen zijn: \(allePlaces)")
                    
                    let langEnLong = json["_embedded"]["events"]
                    for (_,page) in places {
                        
                        
                        let lat = page["_embedded"]["venues"][0]["location"]["latitude"].string
                        if (lat != nil)
                        {
                            alleLatituden.append(lat!)
                        }
                        else
                        {
                            alleLatituden.append("")
                        }
                        let long = page["_embedded"]["venues"][0]["location"]["longitude"].string
                        if (long != nil)
                        {
                            alleLongituden.append(long!)
                        }
                        else
                        {
                            alleLongituden.append("")
                        }
                        
                    }
                    print("lats: \(alleLatituden)")
                    print("longs: \(alleLongituden)")
                    let genres = json["_embedded"]["events"]
                    for (_,page) in genres {
                        
                        
                        let genreVanEvent = page["classifications"][0]["genre"]["name"].string
                        if genreVanEvent != nil
                        {
                            alleGenresVanEvents.append((genreVanEvent)!)
                        }
                        else
                        {
                            alleGenresVanEvents.append("Geen genre")
                        }
                    }
                    print("genres \(alleGenresVanEvents)")
                    
                    let dates = json["_embedded"]["events"]
                    for (_,page) in dates {
                        print(page["name"])
                        
                        
                        
                        let timeVanEvent = page["dates"]["start"]["localTime"].string
                        
                        if timeVanEvent != nil
                        {
                            alleLocalTimeStart.append(timeVanEvent!)
                        }
                        else
                        {
                            alleLocalTimeStart.append("Start time unknown")
                        }
                        
                        let dateVanEvent = page["dates"]["start"]["localDate"].string
                        if dateVanEvent != nil
                        {
                            alleDates.append((dateVanEvent)!)
                        }
                        else
                        {
                            alleDates.append("no start date")
                        }
                        
                        let endTimeVanEvent = page["dates"]["end"]["localTime"].string
                        if endTimeVanEvent != nil
                        {
                            alleLocalTimeEnd.append(endTimeVanEvent!)
                        }
                        else
                        {
                            alleLocalTimeEnd.append("End time unknown")
                        }
                        
                        let endDateVanEvent = page["dates"]["end"]["localDate"].string
                        if endDateVanEvent != nil
                        {
                            alleEndDates.append((endDateVanEvent)!)
                        }
                        else
                        {
                            alleEndDates.append("No end date")
                        }
                    }
                    
                    
                    let EventPlace = json["_embedded"]["events"]
                    for (_,page) in EventPlace {
                        
                        
                        let placeVanEvent = page["seatmap"]["staticUrl"].string
                        if placeVanEvent != nil
                        {
                            allePlacesVanEvents.append((placeVanEvent)!)
                        }
                        else
                        {
                            allePlacesVanEvents.append("")
                        }
                        
                    }
                    print("alle places: \(allePlacesVanEvents)")
                    
                    
                    
                    let fotosVanEvents = json["_embedded"]["events"]
                    for (_,page) in fotosVanEvents {
                        
                        let priceVanEvent = page["priceRanges"][0]["min"].int
                        if priceVanEvent == nil
                        {
                            allePricesvanEvents.append("50")
                        }
                        else
                        {
                            allePricesvanEvents.append(String(priceVanEvent!))
                        }
                        
                        let fotoVanEvent = page["images"][0]["url"].string
                        
                        alleFotosVanEvents.append(fotoVanEvent!)
                        //self.lblEvents.text = self.alleName as? String
                    }
                    print("de prices zijn: \(allePricesvanEvents))")
                    print("Alle foto's: \(alleFotosVanEvents)")
                    print("Alle datums: \(alleDates)")
                    print("al de foto's: \(alleFotosVanEvents.count)")
                    print("al de namen: \(alleName.count)")
                    DispatchQueue.main.async {
                        self.tableview.reloadData()
                    }
                    
                    
                    
                    
                    print("lijst met namen:")
                    if self.lijstMetNamen.count == 0
                    {
                        SwiftSpinner.hide()
                        let alertController = UIAlertController(title: "Concert-Tracker", message:
                            "No Events were found", preferredStyle: UIAlertControllerStyle.alert)
                        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                        
                        self.present(alertController, animated: true, completion: nil)
                    }
                    print(self.lijstMetNamen)
                }
            case .failure(_):
                print("aiaia")
                SwiftSpinner.hide()
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "No internet connection available, please try again", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
            }
        }
    
    //DEZE FUNCTIE WERKTE NIET
    func search(){
        //dataImageView.isHidden = false
        /*
        if teller == 0
        {
        dataImageView.isHidden = true
            teller = 1
        }
        else
        {
            dataImageView.isHidden = false
            teller = 0
        }
        */
        
        //https://app.ticketmaster.com/discovery/v2/events.json?&classificationName=music&sort=date,asc&apikey=91266liFMYink0pu2zFqYCT9yQ3zOYHT
        let url = URL(string: "http://95.85.35.29/selectbyname.php")
        //var request = URLRequest(url:url!)
        //request.httpMethod = "POST"// Compose a query string
        
        //let postString = "name=Graspop"
        
        //request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!)
            
            let desc = String(data: data!, encoding: .utf8)
            print("Response: \(String(describing: desc))")
            print("data:")
            
            var names = [String]()
            
            do {
                //let encoder = JSONEncoder()
                //let encoded = try encoder.encode(response)
                
                //let decoder = JSONDecoder()
                //let decoded = try decoder.decode([response].self, from: encoded)
                
                
                
                if let data = data,
                    let json = try JSONSerialization.jsonObject(with: data) as? [String: Any], 
                    let blogs = json[""] as? [[String: Any]] {
                    for blog in blogs {
                        if let name = blog["NAAM"] as? String {
                            names.append(name)
                        }
                    }
                }
                
                print(names)
                /*
                if let data = data,
                    let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                    let blogs = json["_embedded"] as? [[String: Any]] {
                    for blog in blogs {
                        if let events = blog["event"] as? [[String: Any]] {
                            for event in events {
                                if let name = events["name"] as? String {
                                    for name in names {
                                        names.append(name)
                                    }
                            names.append(name)
                            }
                        }
                    }
                }
                }
                */
            } catch {
                print("Error deserializing JSON: \(error)")
            }
            
            print(names)
            
            
            do {
                
                print("Probeer data..")
                 let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                /*
                var arrayOfData : [String] = []
                DispatchQueue.main.async {
                   
                    for data in (json as! [Dictionary<String,AnyObject>])
                    {
                        let data1 = data["NAAM"]
                        
                        arrayOfData.append(data1 as! String)
                    }
                    
                }
                */
                
                if let parseJSON = json {
                    print(parseJSON)
                    
                    //print("row \(String(describing: json!["row"]))")
                    
                    //let usernameValue = parseJSON["loggedin"] as? String
                    //print("username: \(String(describing: usernameValue))")
                    
                    /*
                     let vc = self.storyboard?.instantiateViewController(withIdentifier: "index") as! indexViewController
                     self.present(vc, animated: true, completion: nil)
                     */
                    //self.load()
                    
                }
                
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any] {
                    print("try")
                    print(json)
                    //let success = json["username"] as? String
                    //print("Voornaam test\(String(describing: success))")
                    //OperationQueue.main.addOperation {
                    //    self.lblWelcomeBack.text = "Welcome back \(success ?? "")!"
                   // }
                }
            } catch let error {
                print(error.localizedDescription)
            }
            
        }
        
        task.resume()
    }
        
       /*
        let myUrl = URL(string: "http://95.85.35.29/selectbyname.php");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"// Compose a query string
        
        //let postString = "name=TESTEVENT"
        
        //request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                print("error=\(String(describing: error))")
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "No internet connection available, please try again", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
                return
            }
            
            // You can print out response object
            print("response = \(String(describing: response))")
            
            //Let's convert response sent from a server side script to a NSDictionary object:
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print(parseJSON)
                    //print("row \(String(describing: json!["row"]))")
                    
                    //let usernameValue = parseJSON["loggedin"] as? String
                    //print("username: \(String(describing: usernameValue))")
                    
                    /*
                     let vc = self.storyboard?.instantiateViewController(withIdentifier: "index") as! indexViewController
                     self.present(vc, animated: true, completion: nil)
                     */
                    //self.load()
                    
                    }
                    //self.stopLoad()
                
        
    

            } catch let error {
                print("Error: ")
                print(error)
                
            }
        }
        task.resume()
        }
    


*/

        /*
        let url = URL(string: "https://concerttracker.aenterprise.info/selectbyname.php")
        
        let task = URLSession.shared.dataTask(with: url! as URL) { data, response, error in
            
            guard let data = data, error == nil else { return }
            
            print(NSString(data: data, encoding: String.Encoding.utf8.rawValue)!)
            
            do {
                let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print(parseJSON)
                    
                    //let test = parseJSON["_embedded"] as? String
                    //print("test123: \(String(describing: test))")
                    //let events = json?.object(forKey: "results")
                    //let names = (events as AnyObject).object(forKey: "name")
                    //print("Test123: \(String(describing: names))")
                    //print(parseJSON.allKeys(for: "_embedded"))
                   // print(embedded!)
                    //let usernameValue = parseJSON["loggedin"] as? String
                    //print("username: \(String(describing: usernameValue))")
                    //let dataArray = json?["name"] as? [String]
                    //var naam = ""
                    /*
                    if let naamArray = json?.value(forKey: "name") as? NSArray {
                        for naam in naamArray
                        {
                            self.TestLabel.text = naam as? String
                        }
                    }
 */
                    //self.TestLabel.text = naam
                    }
                    //self.stopLoad()
                
            } catch let error {
                print("Error: ")
                print(error)
                
            }
        }
        
        task.resume()
        
}
*/
    }
    //Klik op de search knop en toon de foto
    @IBAction func search(_ sender: Any) {
        //search()
        toonSearch()
        searchEvents()
    }
    
    
    

    //log uit
    @IBAction func logout(_ sender: Any) {
        let myUrl = URL(string: "https://concerttracker.aenterprise.info/logout");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                print("error=\(String(describing: error))")
                return
            }
            
            print("response = \(String(describing: response))")
            print("logout btn tap")
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print(parseJSON)
                    let loggedoutValue = parseJSON["loggedout"] as? String
                    print("loggedoutValue: \(String(describing: loggedoutValue))")
                    }
                }
             catch {
                print(error)
            }
        }
    OperationQueue.main.addOperation {
            self.performSegue(withIdentifier: "logOut", sender: self)
        
            task.resume()
        }
    }
}
