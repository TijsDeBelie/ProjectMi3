//
//  OrdersViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 12/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import PDFKit
import PDFGenerator

var userEventNames = [String]()
var userEventAmount = [String]()
var userEventPrice = [String]()
var userEventDates = [String]()
var userEventFotos = [String]()
var korting = 0

class OrdersViewController: UIViewController {
    @IBOutlet weak var lblSlash: UILabel!
    var teller = 0
    @IBOutlet weak var btnInfoOutlet: UIButton!
    @IBOutlet weak var lblKorting: UILabel!
    @IBOutlet weak var lblCurrentDiscount: UILabel!
    @IBOutlet weak var img15percentOff: UIImageView!
    @IBOutlet weak var lblAchtergrond: UILabel!
    
    @IBOutlet weak var lblEventName: UILabel!
    @IBOutlet weak var lblEventDate: UILabel!
    @IBOutlet weak var lblEventAmount: UILabel!
    @IBOutlet weak var lblEventPrice: UILabel!
    
    @IBOutlet weak var orderTableViewOutlet: UITableView!
    
    var userName: String = ""
    var user = ""
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        orderTableViewOutlet.delegate = self
        orderTableViewOutlet.dataSource = self
   
        checkIfShake()
        defaults.setValue("false", forKey: "MeldingOrders")
        print("naam na appear: \(user)")
        
        getOrders2()
    }
    

    override func viewWillAppear(_ animated: Bool) {
        self.img15percentOff.isHidden = true
        //self.lblSlash.isHidden = true
        //self.lblKorting.isHidden = true
            checkSession()
        //haalAchtergrondOp()
        themaKleur()
        
        //getOrders()
        
    }
    
    func imageWithImage(image:UIImage,scaledToSize newSize:CGSize)->UIImage{
        
        UIGraphicsBeginImageContext( newSize )
        image.draw(in: CGRect(x: 0,y: 0,width: newSize.width,height: newSize.height))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!.withRenderingMode(.alwaysOriginal)
    }
    
    @IBAction func btnPay(_ sender: UIButton) {
        //generatePDF()
        let prijsArray = userEventPrice.map { Double($0)!}
        let aantalArray = userEventAmount.map { Double($0)!}
        let totalCost = zip(prijsArray, aantalArray).map { $0 * $1 }
        var totalPrice = totalCost.reduce(0) { $0 + $1 }
        if korting > 0
        {
            let nieuwePrijs = (totalPrice / Double(100.0)) * Double(korting)
            totalPrice = totalPrice - nieuwePrijs
        }
        
        let appearance = SCLAlertView.SCLAppearance(
            showCloseButton: false
        )
        let confirmAlertView = SCLAlertView(appearance: appearance)
        
        confirmAlertView.addButton("Confirm") {
            
            let appearance = SCLAlertView.SCLAppearance(
                kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
                kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
                kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
                
            )
            let succesAlert = SCLAlertView(appearance: appearance)
            succesAlert.showSuccess("Purchase succesful!", subTitle: "Your tickets have been bought!")
            self.UploadDiscount(discountWaarde: 0)
            //self.loadView()
            OperationQueue.main.addOperation {
                self.lblCurrentDiscount.text = "You don't have a discount. Visit our site to get one"
                
                    self.img15percentOff.isHidden = true
                    //self.lblSlash.isHidden = false
                    //self.lblKorting.isHidden = false
                
                
                self.deleteAllOrders()
                
                //self.orderTableViewOutlet.reloadData()
                
            }
        }
        confirmAlertView.addButton("Cancel"){
            print("Second button tapped")
        }
        
        
        confirmAlertView.showInfo("Confirm", subTitle: "Do you want to buy these tickets for a total of: $\(totalPrice)?")
    }
    
    
    //zorg ervoor dat de info knop niet meer springt als je erop hebt geklit
    @IBAction func btnInfo(_ sender: UIButton) {
        defaults.setValue("false", forKey: "btnGetLarger")
    }
    
    //kijk of de info knop moet springen
    func checkIfShake() {
        if defaults.string(forKey: "btnGetLarger") == "true"
        {
            self.btnInfoOutlet.pulsate()
        }
    }
    //haal de themakleur uit de Userdefaults
    func themaKleur() {
        let kleur = defaults.string(forKey: "Thema")
        print("Userdef kleur is: \(String(describing: kleur))")
        if kleur == "blue"
        {
            DispatchQueue.main.async {
                self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
            }
        }
        if kleur == "orange"
        {
            DispatchQueue.main.async {
                self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
            }
        }
        if kleur == "green"
        {
            DispatchQueue.main.async {
                self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
            }
            
        }
    }
    
    //Gebruik ik NIET meer
    func haalAchtergrondOp() {
        let url = URL(string: "https://concerttracker.aenterprise.info/session.php")
        
        let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!)
            print("data:")
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any] {
                    print("try")
                    print(json)
                    
//                    self.userName = (json["username"] as? String)!
//                    print("Username is: \(self.userName)")
                    
                    if (json["Thema"] as? String == "blue")
                    {
                        DispatchQueue.main.async {
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "orange")
                    {
                        DispatchQueue.main.async {
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "green")
                    {
                        DispatchQueue.main.async {
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
                        }
                    }
                }
            } catch let error {
                print(error.localizedDescription)
            }
            
        }
        
        task.resume()
    }
    
    //Kijk of je een korting hebt
    func checkSession() {
        let url = URL(string: "https://concerttracker.aenterprise.info/session.php")
        
        let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!)
            print("data:")
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any] {
                    print("try")
                    print(json)
                    self.userName = (json["username"] as? String)!
                    print("Username is?: \(self.userName)")
                    let naam = json["username"] as? String
                    self.user = naam!
                    print("usernaaaaam: \(self.userName)")
                    print("naaaaam: \(self.user)")
                    let success = json["Discount"] as! String
                    print("Discount test\(String(describing: success))")
                    korting = Int(success)!
                    OperationQueue.main.addOperation {
                        self.lblCurrentDiscount.text = "You don't have a discount. Visit our site to get one"
                        if success == "15"
                        {
                            self.lblCurrentDiscount.text = "You have a discount of: \(success)"
                        self.img15percentOff.isHidden = false
                            //self.lblSlash.isHidden = false
                            //self.lblKorting.isHidden = false
                        }
                    }
                }
            } catch let error {
                print(error.localizedDescription)
            }
            
        }
        
        task.resume()
    }
    func deleteAllOrders() {
        print("te deleten: \(userNameInApp)")
        let parameters = [
            "user": userNameInApp,
            ]
        var statusCode: Int = 0
        Alamofire.request("https://concerttracker.aenterprise.info/DeleteAllOrders.php", method: .post, parameters: parameters)
            .responseJSON { response in
                statusCode = (response.response?.statusCode)! //Gets HTTP status code, useful for debugging
                print(statusCode)
                
        }
        userEventNames.removeAll()
        userEventDates.removeAll()
        userEventPrice.removeAll()
        userEventAmount.removeAll()
        userEventFotos.removeAll()
        self.orderTableViewOutlet.reloadData()
    }
    
    func getOrders2() {
        userEventNames.removeAll()
        userEventDates.removeAll()
        userEventPrice.removeAll()
        userEventAmount.removeAll()
        userEventFotos.removeAll()
        print("orderusername: \(user)")
        let parameters = [
            "User": userNameInApp,
        ]
        var statusCode: Int = 0
        Alamofire.request("https://concerttracker.aenterprise.info/orders.php", method: .post, parameters: parameters)
            .responseJSON { response in
                statusCode = (response.response?.statusCode)! //Gets HTTP status code, useful for debugging
                print(statusCode)
                if let value: AnyObject = response.result.value as AnyObject {
                let json = JSON(value)
                print("lalalala \(json)")
                    
                    let pages = json
                    for (_,page) in pages {
                        //print(page["EVENTNAME"])
                        userEventNames.append(page["EVENTNAME"].string!)
                        userEventPrice.append(page["PRICE"].string!)
                        userEventAmount.append(page["AMOUNT"].string!)
                        userEventDates.append(page["DATE"].string!)
                        userEventFotos.append(page["Event_Foto"].string!)
                        //self.lblEvents.text = self.alleName as? String
                    }
                    print(userEventNames)
                    print(userEventAmount)
                    print(userEventPrice)
                    self.orderTableViewOutlet.reloadData()
                }
        }
        
    }
    
    func getOrders() {
        let url = URL(string: "https://concerttracker.aenterprise.info/orders.php")
        
        var request = URLRequest(url:url!)
        request.httpMethod = "POST"// Compose a query string
        
        let postString = "User=\(self.userName)"
        print("username issss: \(self.userName)")
        print("geen username meer")
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                
                
                print("error=\(String(describing: error))")
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "No internet connection available, please try again", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
                return
            }
            
            print("response = \(String(describing: response))")
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print("de json is: ")
                    print(parseJSON)
                    }
                }
                        
                        
        
             catch let error {
                print("Error: ")
                print(error)
                
            }
        }
        task.resume()
    }
}
extension OrdersViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userEventNames.count
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            
            
            
            
            let parameters = [
                "User": userNameInApp,
                "Order": userEventNames[indexPath.row]
                ] as [String : Any]
            print("params: ")
            print(parameters)
            var statusCode: Int = 0                                      
            Alamofire.request("https://concerttracker.aenterprise.info/DeleteOrder.php", method: .post, parameters: parameters)
                .responseJSON { response in
                    statusCode = (response.response?.statusCode)! //Gets HTTP status code, useful for debugging
                    print(statusCode)
                    if let value: AnyObject = response.result.value as AnyObject {
                        let json = JSON(value)
                        print("lalalala \(json)")
                        
                        
                    }
            }
            userEventNames.remove(at: indexPath.row)
            userEventAmount.remove(at: indexPath.row)
            userEventPrice.remove(at: indexPath.row)
            userEventDates.remove(at: indexPath.row)
            userEventFotos.remove(at: indexPath.row)
            
            
            tableView.beginUpdates()
            //userEventNames.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
            tableView.reloadData()
        }
    }
    
    func UploadDiscount(discountWaarde: Int) {
        
        let myUrl = URL(string: "https://concerttracker.aenterprise.info/discount.php");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"
        
        let postString = "value=\(discountWaarde)&user=\(userNameInApp)"
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                print("error=\(String(describing: error))")
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "No internet connection available, please try again", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print(parseJSON)
                    
                }
            }
            catch let error {
                print("Error: ")
                print(error)
                
            }
        }
        task.resume()
    }
    
    func generatePDF() {
        let v1 = UIScrollView(frame: CGRect(x: 0.0,y: 0, width: 100.0, height: 100.0))
        let v2 = UIView(frame: CGRect(x: 0.0,y: 0, width: 100.0, height: 200.0))
        let v3 = UIView(frame: CGRect(x: 0.0,y: 0, width: 100.0, height: 200.0))
        v1.backgroundColor = .red
        v1.contentSize = CGSize(width: 100.0, height: 200.0)
        v2.backgroundColor = .green
        v3.backgroundColor = .blue
        
        let dst = URL(fileURLWithPath: NSTemporaryDirectory().appending("sample1.pdf"))
        // outputs as Data
        do {
            let data = try PDFGenerator.generated(by: [v1, v2, v3])
            try data.write(to: dst, options: .atomic)
        } catch (let error) {
            print(error)
        }
        
        // writes to Disk directly.
        do {
            try PDFGenerator.generate([v1, v2, v3], to: dst)
        } catch (let error) {
            print(error)
        }
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let eventNaam = userEventNames[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "orderCell") as! OrdersTableViewCell
        
        cell.lblEventName.text = userEventNames[indexPath.row]
        
        cell.lblEventDate.text = userEventDates[indexPath.row]
        
        var prijs = Double(userEventPrice[indexPath.row])! * Double(userEventAmount[indexPath.row])!
        var standaardPrijs = Double(userEventPrice[indexPath.row])!
        if korting > 0
        {
            let nieuwePrijs = (prijs / 100) * Double(korting)
            prijs = prijs - nieuwePrijs
            cell.lblEventPrice.textColor = UIColor(red: 94/255, green: 142/255, blue: 83/255, alpha: 1.0)
            cell.lblEventPrice.text = "Total: \(prijs)"
            let nieuweStandaardPrijs = (standaardPrijs / 100) * Double(korting)
            standaardPrijs = standaardPrijs - nieuweStandaardPrijs
            cell.lblEventAmount.text = "\(userEventAmount[indexPath.row])x $\(standaardPrijs)"
        }
        else
        {
            cell.lblEventPrice.text = "Total: $\(prijs)"
            cell.lblEventAmount.text = "\(userEventAmount[indexPath.row])x $\(standaardPrijs)"
        }
        cell.imgEventFoto.sd_setImage(with: URL(string: userEventFotos[indexPath.row]), placeholderImage: UIImage(named: "no_Image_Available.png"))
        
        return cell
    }
    
    }
    
    


