//
//  ViewController.swift
//  QRReader
//
//  Created by Sebastian Hette on 17.07.2017.
//  Copyright © 2017 MAGNUMIUM. All rights reserved.
//
import UIKit
import AVFoundation
import AudioToolbox

class QRViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    let session = AVCaptureSession()
    @IBOutlet weak var square: UIImageView!
    var video = AVCaptureVideoPreviewLayer()
    var userName: String = ""
    var defaults = UserDefaults.standard
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Sessie?")
        //self.checkSession()
        haalUsernameUitUserdefaults()
        maakEnStartQRCodeSessie()
        
    }
    //De functienaam lijkt me duidelijk genoeg
    func maakEnStartQRCodeSessie() {
        let captureDevice = AVCaptureDevice.default(for: .video)
        
        do
        {
            let input = try AVCaptureDeviceInput(device: captureDevice!)
            session.addInput(input)
        }
        catch
        {
            print ("ERROR")
        }
        
        let output = AVCaptureMetadataOutput()
        session.addOutput(output)
        
        output.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        
        output.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
        
        video = AVCaptureVideoPreviewLayer(session: session)
        
        video.frame = view.layer.bounds
        view.layer.addSublayer(video)
        
        self.view.bringSubview(toFront: square)
        
        session.startRunning()

    }
    
    //Kijk of we iets nuttigs scannen en sla de discount op in de database als je de juiste qr code scant
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        //metadataObjects != nil &&
        if metadataObjects.count != 0
        {
            if let object = metadataObjects[0] as? AVMetadataMachineReadableCodeObject
            {
                if object.type == AVMetadataObject.ObjectType.qr
                {
                    
                    //You will receive 15% discount when you buy tickets
                    if object.stringValue == "U53994654Su"
                    {
                        defaults.setValue("true", forKey: "MeldingOrders")
                        AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))  
                        print("discount succes")
                        let alertController = UIAlertController(title: "Succesful!", message:
                            "You will receive 15% discount when you buy tickets", preferredStyle: UIAlertControllerStyle.alert)
                        let okAction = UIAlertAction(title: "Continue>>", style: UIAlertActionStyle.default) {
                            UIAlertAction in
                            self.navigationController?.popViewController(animated: false)
                            self.UploadDiscount(discountWaarde: 15)
                            print("discount succes2")
                        }
                        self.session.stopRunning()
                        alertController.addAction(okAction)
                        self.present(alertController, animated: true, completion: nil)
                        return
                    }
                    else
                    {
                        let alert = UIAlertController(title: "QR Code", message: object.stringValue, preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Incorrect QR code, Try Again", style: .default, handler: nil))
                        
                        present(alert, animated: true, completion: nil)
                    }
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //Haal de lokaal opgeslagen username uit de userdefaults (deze hebben we opgevuld met de username als de sessie werd aangemaakt)
    func haalUsernameUitUserdefaults() {
        userName = (defaults.string(forKey: "Username"))!
    }
    
    //Upload de korting naar de database
    func UploadDiscount(discountWaarde: Int) {

        let myUrl = URL(string: "https://concerttracker.aenterprise.info/discount.php");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"
        
        let postString = "value=\(discountWaarde)&user=\(userName)"
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                print("error=\(String(describing: error))")
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "No internet connection available, please try again", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
                return
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print(parseJSON)
                    
                    }
                }
             catch let error {
                print("Error: ")
                print(error)
                
            }
        }
        task.resume()
}
}
