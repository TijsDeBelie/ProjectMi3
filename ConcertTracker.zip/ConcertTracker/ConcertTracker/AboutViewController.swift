//
//  AboutViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 2/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {

    @IBOutlet weak var lblTitel: UILabel!
    @IBOutlet weak var lblAchtergrond: UILabel!
    
    @IBOutlet weak var SenneOutlet: UIImageView!
    @IBOutlet weak var ManonOutlet: UIImageView!
    
    var userName: String = ""
    let defaults = UserDefaults.standard
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //haalAchtergrondOp()
        themaKleur()
    }
    //Hier haal in de achtergrond kleur op die ik lokaal heb opgeslagen uit de session.
    func themaKleur() {
        let kleur = defaults.string(forKey: "Thema")
        print("Userdef kleur is: \(String(describing: kleur))")
        if kleur == "blue"
        {
            DispatchQueue.main.async {
                
                self.lblTitel.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
                
                self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
            }
        }
        if kleur == "orange"
        {
            DispatchQueue.main.async {
                
                self.lblTitel.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
                
                self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
            }
        }
        if kleur == "green"
        {
            DispatchQueue.main.async {
                
                self.lblTitel.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
                
                self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
            }
            
        }
    }
    //Hier vergroot ik de afbeelding als je erop klikt en maak ik de achtergrond zwart
    @IBAction func SenneTap(_ sender: UITapGestureRecognizer)
    {   let imageView = sender.view as! UIImageView
        let newImageView = UIImageView(image: imageView.image)
        newImageView.frame = UIScreen.main.bounds
        newImageView.backgroundColor = .black
        newImageView.contentMode = .scaleAspectFit
        newImageView.isUserInteractionEnabled = true
        
        UIView.animate(withDuration: 0, animations: {() -> Void in
            newImageView.transform = CGAffineTransform(scaleX: 0, y: 0)
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.5, animations: {() -> Void in
                newImageView.transform = CGAffineTransform(scaleX: 1, y: 1)
            })
        })

        
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissFullscreenImage))
        newImageView.addGestureRecognizer(tap)
        self.view.addSubview(newImageView)
        self.navigationController?.isNavigationBarHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    //Hier sluit ik de full screen afbeelding
    @objc func dismissFullscreenImage(_ sender: UITapGestureRecognizer) {
        self.navigationController?.isNavigationBarHidden = false
        self.tabBarController?.tabBar.isHidden = false
        sender.view?.removeFromSuperview()
    }
    //Hier vergroot ik de afbeelding als je erop klikt en maak ik de achtergrond zwart
    @IBAction func ManonTap(_ sender: UITapGestureRecognizer) {
        let imageView = sender.view as! UIImageView
        let newImageView = UIImageView(image: imageView.image)
        newImageView.frame = UIScreen.main.bounds
        newImageView.backgroundColor = .black
        newImageView.contentMode = .scaleAspectFit
        newImageView.isUserInteractionEnabled = true
        
        UIView.animate(withDuration: 0, animations: {() -> Void in
            newImageView.transform = CGAffineTransform(scaleX: 0, y: 0)
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.5, animations: {() -> Void in
                newImageView.transform = CGAffineTransform(scaleX: 1, y: 1)
            })
        })
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissFullscreenImage))
        newImageView.addGestureRecognizer(tap)
        self.view.addSubview(newImageView)
        self.navigationController?.isNavigationBarHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    //Hier vergroot ik de afbeelding als je erop klikt en maak ik de achtergrond zwart
    @IBAction func TijsTap(_ sender: UITapGestureRecognizer) {
        let imageView = sender.view as! UIImageView
        let newImageView = UIImageView(image: imageView.image)
        newImageView.frame = UIScreen.main.bounds
        newImageView.backgroundColor = .black
        newImageView.contentMode = .scaleAspectFit
        newImageView.isUserInteractionEnabled = true
        
        UIView.animate(withDuration: 0, animations: {() -> Void in
            newImageView.transform = CGAffineTransform(scaleX: 0, y: 0)
        }, completion: {(_ finished: Bool) -> Void in
            UIView.animate(withDuration: 0.5, animations: {() -> Void in
                newImageView.transform = CGAffineTransform(scaleX: 1, y: 1)
            })
        })
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissFullscreenImage))
        newImageView.addGestureRecognizer(tap)
        self.view.addSubview(newImageView)
        self.navigationController?.isNavigationBarHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    //GEBRUIK IK NIET MEER, ik heb dit performanter gemaakt zodat je niet altijd internet nodig hebt om een viewcontroller te laden.
    func haalAchtergrondOp() {
        let url = URL(string: "https://concerttracker.aenterprise.info/session.php")
        
        let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!)
            print("data:")
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any] {
                    print("try")
                    print(json)
                    
                    self.userName = (json["username"] as? String)!
                    print("Username is: \(self.userName)")
                    
                    if (json["Thema"] as? String == "blue")
                    {
                        DispatchQueue.main.async {
                            
                            
                                self.lblTitel.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
                            self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "orange")
                    {
                        DispatchQueue.main.async {
                            
                            self.lblTitel.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
                            self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "green")
                    {
                        DispatchQueue.main.async {
                            
                            
                            self.lblTitel.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
                            self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
                        }
                        
                    }
                    
                }
            } catch let error {
                print(error.localizedDescription)
            }
        }
        
        task.resume()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
