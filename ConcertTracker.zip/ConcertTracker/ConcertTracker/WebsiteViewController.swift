//
//  WebsiteViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 25/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit

class WebsiteViewController: UIViewController, UIWebViewDelegate {
    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.delegate = self
        loadAddress()
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        
    }
    func loadAddress() {
        //activity.startAnimating()
        let url = URL(string: alleUrlVanEvents[myIndex])
        webView.loadRequest(URLRequest(url: url!))
    }
    func webViewDidStartLoad(_ webView: UIWebView){
    
        activity.startAnimating()
        print("start loading")
    }
    func webViewDidFinishLoad(_ webView: UIWebView){
    
        activity.stopAnimating()
        activity.isHidden = true
        print("stop loading")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
