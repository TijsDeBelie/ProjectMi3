//
//  SettingsViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 12/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    @IBOutlet weak var btnOrdersOutlet: UIButton!
    let defaults = UserDefaults.standard
    @IBOutlet weak var lblAchtergrond: UILabel!
    @IBOutlet weak var lblTutorial: UILabel!
    
    @IBOutlet weak var switchTutorial: UISwitch!
    @IBOutlet weak var BallOutlet: UIImageView!
    
    @IBOutlet weak var lblAdminOnly: UILabel!
    var userName: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        //haalDataOp()
        themaKleur()
        checkBallOrder()
        checkIfAdmin()
        checkIfTutIsUp()
        lblTutorial.layer.cornerRadius = 5
        lblTutorial.layer.borderWidth = 2
        lblTutorial.layer.borderColor = UIColor.gray.cgColor
    }
    
    //Kijk of je een admin bent en als je de switch in de settings hebt aangezet
    func checkIfTutIsUp() {
        if defaults.value(forKey: "TutAdmin") as? String == "ja"
        {
            switchTutorial.isOn = true
        }
        else
        {
            switchTutorial.isOn = false
        }
    }

    //kijk of er een melding moet staan op de knop 'Orders' nadat je de juiste qr code hebt gescand
    func checkBallOrder() {
        let ball = defaults.string(forKey: "MeldingOrders")
        if ball == "true"
        {
            BallOutlet.isHidden = false
        }
        if ball == "false"
        {
            BallOutlet.isHidden = true
        }
    }
    //sla op of je de switch aan hebt gezet of niet om de tutorial weer te geven (admin only)
    @IBAction func switchTutorialValueChanged(_ sender: Any) {
        print("checged")
        if switchTutorial.isOn == true
        {
            defaults.set("ja", forKey: "TutAdmin")
            print(defaults.string(forKey: ("TutAdmin"))!)
        }
        else
        {
            defaults.set("nee", forKey: "TutAdmin")
            print(defaults.string(forKey: ("TutAdmin"))!)
        }
    }
    
    //kijk of je admin bent, en indien ja toon je de switch om de tutorial aan of uit te zetten.
    func checkIfAdmin() {
        if defaults.value(forKey: "Admin") as? Bool == true
        {
            lblTutorial.isHidden = false
            switchTutorial.isHidden = false
            lblAdminOnly.isHidden = false
        }
        
    }
    //Hier haal in de achtergrond kleur op die ik lokaal heb opgeslagen uit de session.
    func themaKleur() {
        let kleur = defaults.string(forKey: "Thema")
        print("Userdef kleur is: \(String(describing: kleur))")
        if kleur == "blue"
        {
            DispatchQueue.main.async {
                self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
            }
        }
        if kleur == "orange"
        {
            DispatchQueue.main.async {
                self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
            }
        }
        if kleur == "green"
        {
            DispatchQueue.main.async {
                self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
            }
        }
    }
    //Gebruik ik NIET meer
    func haalDataOp() {
        let url = URL(string: "https://concerttracker.aenterprise.info/session.php")
        
        let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!)
            print("data:")
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any] {
                    print("try")
                    print(json)
                    
                    self.userName = (json["username"] as? String)!
                    print("Username is: \(self.userName)")
                    
                    if (json["Thema"] as? String == "blue")
                    {
                        DispatchQueue.main.async {
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "orange")
                    {
                        DispatchQueue.main.async {
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "green")
                    {
                        DispatchQueue.main.async {
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
                        }
                    }
                }
            } catch let error {
                print(error.localizedDescription)
            }
        }        
        task.resume()
    }
    @IBAction func btnOrders(_ sender: UIButton) {
        //defaults.setValue("false", forKey: "MeldingOrders")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
