//
//  EventInfoViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 24/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit
import MapKit
import Alamofire
import SwiftyJSON

class EventInfoViewController: UIViewController, UITextFieldDelegate {
    
    

    @IBOutlet weak var lblEventName: UILabel!
    
    @IBOutlet weak var imgEventFoto: UIImageView!
    
    @IBOutlet weak var lblEventInfo: UILabel!
    
    @IBOutlet weak var lblEventDate: UILabel!
    
    @IBOutlet weak var lblGenre: UILabel!
    
    @IBOutlet weak var lblSeatMap: UILabel!
    
    @IBOutlet weak var imgSeatMap: UIImageView!
    
    @IBOutlet weak var pageHeight: NSLayoutConstraint!
    
    @IBOutlet weak var lblLoaction: UILabel!
    
    @IBOutlet weak var lblEndEvent: UILabel!
    
    @IBOutlet weak var pageView: UIView!
    
    @IBOutlet weak var lblMap: UILabel!
    
    @IBOutlet weak var imgMap: UIImageView!
    
    @IBOutlet weak var txtAmount: UITextField!
    
    @IBOutlet weak var lblPrice: UILabel!
    
    var activeTextField: UITextField!
    var amountTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //txtAmount.delegate = self
//        let center: NotificationCenter = NotificationCenter.default;
//        center.addObserver(self, selector: #selector(keyboardDidShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
//        center.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
        lblEventInfo.layer.borderWidth = 0.5
        lblEventInfo.layer.borderColor = UIColor.black.cgColor
        lblEventInfo.layer.cornerRadius = 5
        
        lblEventName.text = alleName[myIndex]
        lblEventDate.text = "Start date: " + alleDates[myIndex] + " @ " + alleLocalTimeStart[myIndex]
        lblEventInfo.text = alleInfoVanEvents[myIndex]
        lblGenre.text = "Genre: " + alleGenresVanEvents[myIndex]
        lblLoaction.text = "Location: " + allePlaces[myIndex]
        lblEndEvent.text = "End date: " + alleEndDates[myIndex] + " @ " + alleLocalTimeEnd[myIndex]
        lblPrice.text = "Price: $" + allePricesvanEvents[myIndex]
        
        let (seatMap) = allePlacesVanEvents [myIndex]
        if seatMap != ""
        {
            
            //lblSeatMap.isHidden = false
            let url = URL(string: seatMap)
            let data = try? Data(contentsOf: url!)
            imgSeatMap.image = UIImage(data: (data)!)!
        }
        else
        {
            imgSeatMap.image = UIImage(named: "no_Image_Available.png")
            //imgSeatMap.isHidden = true
            pageHeight.constant -= 200
            //imgSeatMap.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
        }
        
        let (map) = alleLatituden [myIndex]
        if map != ""
        {
            //pageHeight.constant += 200
            lblMap.isHidden = false
            let url = URL(string: "https://maps.googleapis.com/maps/api/staticmap?center=" + alleLatituden [myIndex] + "," + alleLongituden [myIndex] + "&zoom=13&size=500x200&maptype=roadmap&markers=color:red%7Clabel:A%7C" + alleLatituden [myIndex] + "," + alleLongituden [myIndex] + "&key=AIzaSyCF_y2ndka9dlzm9HeRhuJi-4Uv1Rm_4j4")
            let data = try? Data(contentsOf: url!)
            imgMap.image = UIImage(data: (data)!)!
        }
        else
        {
            imgMap.image = UIImage(named: "no_Image_Available.png")
            //pageHeight.constant -= 400
        }
        
        
        let (fotos) = alleFotosVanEvents [myIndex]
        if fotos != ""
        {
        let url2 = URL(string: fotos)
        let data2 = try? Data(contentsOf: url2!)
        imgEventFoto.image = UIImage(data: (data2)!)!
        }
        else
        {
            imgEventFoto.image = UIImage(named: "no_Image_Available.png")
        }
        // Do any additional setup after loading the view.
    }
    
//    @objc func keyboardDidShow(notification: Notification) {
//        let info:NSDictionary = notification.userInfo! as NSDictionary
//        let keyboardSize = (info[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
//        let keyboardY = self.view.frame.size.height - keyboardSize.height
//
//        let editingTextFieldY:CGFloat! = self.activeTextField?.frame.origin.y
//
//        if self.view.frame.origin.y >= 0 {
//            //Checking if the textfield is really hidden behind the keyboard
//            if editingTextFieldY > keyboardY - 40 {
//                UIView.animate(withDuration: 0.25, delay: 0.0, options: UIViewAnimationOptions.curveEaseIn, animations: {
//                    self.view.frame = CGRect(x: 0, y: self.view.frame.origin.y - (editingTextFieldY! - (keyboardY - 60)), width: self.view.bounds.width,height: self.view.bounds.height)
//                }, completion: nil)
//            }
//        }
//    }
//    @objc func keyboardWillHide(notification: Notification) {
//            UIView.animate(withDuration: 0.25, delay: 0.0, options: UIViewAnimationOptions.curveEaseIn, animations: {
//                self.view.frame = CGRect(x: 0, y: 0,width: self.view.bounds.width, height: self.view.bounds.height)
//            }, completion: nil)
//
//    };

    
    @IBAction func btnOpenInMaps(_ sender: UIButton) {
        let latitude = Double(alleLatituden[myIndex])
        let longitude = Double(alleLongituden[myIndex])
        
        let regionDistance:CLLocationDistance = 1000
        let coordinates = CLLocationCoordinate2D(latitude: latitude!, longitude: longitude!)
        let regionSpan = MKCoordinateRegionMakeWithDistance(coordinates, regionDistance, regionDistance)
        let options = [
            MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),
            MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)
        ]
        let placemark = MKPlacemark(coordinate: coordinates, addressDictionary: nil)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = alleName[myIndex]
        mapItem.openInMaps(launchOptions: options)
    }
    
    
    @IBAction func TitelTapped(_ sender: UITapGestureRecognizer) {
        let imageView = sender.view as! UIImageView
        let newImageView = UIImageView(image: imageView.image)
        newImageView.frame = UIScreen.main.bounds
        newImageView.backgroundColor = .black
        newImageView.contentMode = .scaleAspectFit
        newImageView.isUserInteractionEnabled = true
        
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissFullscreenImage))
        newImageView.addGestureRecognizer(tap)
        self.view.addSubview(newImageView)
        self.navigationController?.isNavigationBarHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    //Hier sluit ik de full screen afbeelding
    @objc func dismissFullscreenImage(_ sender: UITapGestureRecognizer) {
        self.navigationController?.isNavigationBarHidden = false
        self.tabBarController?.tabBar.isHidden = false
        sender.view?.removeFromSuperview()
        
    }
    @IBAction func SeatMapTapped(_ sender: UITapGestureRecognizer) {
        let imageView = sender.view as! UIImageView
        let newImageView = UIImageView(image: imageView.image)
        newImageView.frame = UIScreen.main.bounds
        newImageView.backgroundColor = .black
        newImageView.contentMode = .scaleAspectFit
        newImageView.isUserInteractionEnabled = true
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissFullscreenImage))
        newImageView.addGestureRecognizer(tap)
        self.view.addSubview(newImageView)
        self.navigationController?.isNavigationBarHidden = true
        self.tabBarController?.tabBar.isHidden = true
    

    }
    
    @IBAction func MapTapped(_ sender: UITapGestureRecognizer) {
        let imageView = sender.view as! UIImageView
        let newImageView = UIImageView(image: imageView.image)
        newImageView.frame = UIScreen.main.bounds
        newImageView.backgroundColor = .black
        newImageView.contentMode = .scaleAspectFit
        newImageView.isUserInteractionEnabled = true
        
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(dismissFullscreenImage))
        newImageView.addGestureRecognizer(tap)
        self.view.addSubview(newImageView)
        self.navigationController?.isNavigationBarHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeTextField = textField
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func addEventToOrderList() {
        let fotooo = alleFotosVanEvents[myIndex]
        print("de foto is \(alleFotosVanEvents[myIndex])")
        //let juisteFoto = alleFotosVanEvents[myIndex].replacingOccurrences(of: "\\/", with: "/")
        
        let appearance = SCLAlertView.SCLAppearance(
            showCloseButton: false, showCircularIcon: true
        )
        let alert = SCLAlertView(appearance: appearance)
        let alertViewIcon = UIImage(named: "tickets.png")
        let txt = alert.addTextField("Amount")
        alert.addButton("Order Tickets") {
            if let nummer = Int(txt.text!)
            {
                if nummer > 0
                {
                    let parameters = [
                        "User": userNameInApp,
                        "EventName": alleName[myIndex],
                        "EventPlace": allePlaces[myIndex],
                        "Price": Int(allePricesvanEvents[myIndex])!,
                        "Foto": fotooo,
                        "EventDate": alleDates[myIndex],
                        "Amount": Int(txt.text!)!
                        ] as [String : Any]
                    print("params: ")
                    print(parameters)
                    var statusCode: Int = 0                                      //IOS
                    Alamofire.request("https://concerttracker.aenterprise.info/buyIOS.php", method: .post, parameters: parameters)
                        .responseJSON { response in
                            statusCode = (response.response?.statusCode)! //Gets HTTP status code, useful for debugging
                            print(statusCode)
                            if let value: AnyObject = response.result.value as AnyObject {
                                let json = JSON(value)
                                print("lalalala \(json)")
                                
                                
                            }
                    }
                    let succesAlert = SCLAlertView()
                    succesAlert.showSuccess("Order Complete!", subTitle: "Your tickets have been added to your oder list")
                }
                else
                {
                    let alertController = UIAlertController(title: "Concert-Tracker", message:
                        "You can't enter 0!", preferredStyle: UIAlertControllerStyle.alert)
                    alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                    
                    self.present(alertController, animated: true, completion: nil)
                    
                    return
                }
            }
            else
            {
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "This is not a valid number!", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
                
                return
            }
        }
        alert.addButton("Cancel") {
            
        }
        alert.showEdit("Order Tickets", subTitle: "How many tickets do you want for:\n\(alleName[myIndex])?", circleIconImage: alertViewIcon)

        
        
    }
            
    @IBAction func btnAddToWatchlist(_ sender: UIButton) {
        addEventToOrderList()
        //txtAmount.resignFirstResponder()
}

    func addEvent() {
        let myUrl = URL(string: "https://concerttracker.aenterprise.info/buyIOS.php");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"
        
        
        
        let postString = "User=\(userNameInApp)&EventName=\(alleName[myIndex])&EventPlace=\(allePlaces[myIndex])&Price=50&Foto=\(alleFotosVanEvents[myIndex])&EventDate=\(alleDates[myIndex])&Amount=\(txtAmount.text!)"
        print("poststring is: \(postString)")
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                
                print("error=\(String(describing: error))")
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "No internet connection available, please try again", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
                
                return
            }
            
            print("response = \(String(describing: response))")
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print(parseJSON)
                    
                    let naamVanEvent = parseJSON["eventname"] as? String
                    print("naamVanEvent: \(String(describing: naamVanEvent))")
                    print("de error is: \(String(describing: json!["error"]))")
                    //                    let usernameValue = parseJSON["loggedin"] as? String
                    //                    print("username: \(String(describing: usernameValue))")
                    
                    
                    
                }
            } catch let error {
                print("Error: ")
                print(error)
                
            }
        }
        task.resume()
    }
}
