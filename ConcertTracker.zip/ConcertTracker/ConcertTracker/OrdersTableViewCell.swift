//
//  OrdersTableViewCell.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 30/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit

class OrdersTableViewCell: UITableViewCell {

    @IBOutlet weak var lblEventName: UILabel!
    @IBOutlet weak var lblEventDate: UILabel!
    @IBOutlet weak var lblEventAmount: UILabel!
    @IBOutlet weak var lblEventPrice: UILabel!
    @IBOutlet weak var imgEventFoto: UIImageView!
    
    func setOrders(order: Orders) {
        lblEventName.text = order.EventTitel
        lblEventDate.text = order.EventDate
        lblEventAmount.text = String(order.EventAmount)
        lblEventPrice.text = String(order.EventPrice)
    }

}
