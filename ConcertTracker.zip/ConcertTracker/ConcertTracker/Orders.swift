//
//  Orders.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 30/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import Foundation
import UIKit

class Orders {
    var EventTitel: String
    var EventDate: String
    var EventAmount: Int
    var EventPrice: Double
    
    init(titel: String, date: String, amount: Int, price: Double) {
        self.EventTitel = titel
        self.EventDate = date
        self.EventAmount = amount
        self.EventPrice = price
    }
}
