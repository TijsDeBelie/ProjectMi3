//
//  CreateAccountViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 1/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit
import CoreData

class CreateAccountViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var lblTitel: UILabel!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtRepeatPassword: UITextField!
    @IBOutlet weak var CreateAccountOutlet: UIButton!
    @IBOutlet weak var CancelOutlet: UIButton!
    @IBOutlet weak var lblError: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtUserName.delegate = self
        txtPassword.delegate = self
        txtRepeatPassword.delegate = self
        
        txtUserName.layer.masksToBounds = true
        txtUserName.layer.cornerRadius = 5
        txtPassword.layer.masksToBounds = true
        txtPassword.layer.cornerRadius = 5
        txtRepeatPassword.layer.masksToBounds = true
        txtRepeatPassword.layer.cornerRadius = 5
        CreateAccountOutlet.layer.masksToBounds = true
        CreateAccountOutlet.layer.cornerRadius = 5
        CancelOutlet.layer.masksToBounds = true
        CancelOutlet.layer.cornerRadius = 5
        CancelOutlet.layer.borderWidth = 0.5
        CancelOutlet.layer.borderColor = UIColor.blue.cgColor
        print("CreateViewLoaded")
    }
    
    //De functie createAccount oproepen als je op de knop 'CreateAccount' klikt
    @IBAction func btnCreateAccount(_ sender: Any) {
        createAccount()
    }
    
    //Create een account EN sla de username en password lokaal op zodat deze kunnen worden ingevuld als je naar het loginscherm gaat.
    func createAccount() {
        
        let myUrl = URL(string: "https://concerttracker.aenterprise.info/create.php");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"
        
        let postString = "usernameCreate=\(txtUserName.text!)&password1=\(txtPassword.text!)&password2=\(txtRepeatPassword.text!)"
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                print("error=\(String(describing: error))")
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "No internet connection available, please try again", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
                return
            }

            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print(parseJSON)
                    DispatchQueue.main.async {
                    self.lblError.text = json?["error"] as? String
                        if json?["created"] as? String == "created"
                        {
                            let alertController = UIAlertController(title: "Concert-Tracker", message:
                                "Your account has been created! You will be directed to the login page", preferredStyle: UIAlertControllerStyle.alert)
                            let okAction = UIAlertAction(title: "Continue>>", style: UIAlertActionStyle.default) {
                                UIAlertAction in
                                
                                OperationQueue.main.addOperation {
                                    self.performSegue(withIdentifier: "gaNaarLogin", sender: self)
                                    
                                    
                                        let appDelegate = UIApplication.shared.delegate as! AppDelegate
                                        
                                        let context = appDelegate.persistentContainer.viewContext
                                        //Hier delete ik de vorige username en password
                                        let ReqVar = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
                                        let DelAllReqVar = NSBatchDeleteRequest(fetchRequest: ReqVar)
                                        do { try context.execute(DelAllReqVar) }
                                        catch { print(error) }
                                        
                                        //Hier zet ik een nieuwe username en password in de lokale database
                                        let newUser = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context)
                                        
                                        print("Switch: \((newUser.value(forKey: "password") != nil))")
                                        newUser.setValue(self.txtUserName.text, forKey: "username")
                                        newUser.setValue(self.txtPassword.text, forKey: "password")

                                        
                                        newUser.setValue("true", forKey: "switchRememberMe")
                                    
                                        do {
                                            try context.save()
                                        } catch {
                                            print("Failed saving")
                                        }

                                }
                            }
                            alertController.addAction(okAction)
                            self.present(alertController, animated: true, completion: nil)
                            return
            
                        }
                    }

                }
            } catch let error {
                print("Error: ")
                print(error)
                
            }
        }
        task.resume()
    }
    
    //De standaard functie van een tekstfield om te bepalen wat er moet gebeuren als je op de knop rechts onderaan het toetsenbord klikt
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        if textField == txtUserName { // Switch focus to other text field
            txtPassword.becomeFirstResponder()
        }
        if textField == txtPassword { // Switch focus to other text field
            txtRepeatPassword.becomeFirstResponder()
        }
        
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
