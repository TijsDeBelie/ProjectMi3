//
//  DiscountInfoViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 16/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit

class DiscountInfoViewController: UIViewController {

    var userName: String = ""
    let defaults = UserDefaults.standard
    @IBOutlet weak var lblAchtergrond: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //haalAchtergrondOp()
        themaKleur()
    }
    //Hier haal in de achtergrond kleur op die ik lokaal heb opgeslagen uit de session.
    func themaKleur() {
        let kleur = defaults.string(forKey: "Thema")
        print("Userdef kleur is: \(String(describing: kleur))")
        if kleur == "blue"
        {
            DispatchQueue.main.async {
                self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
            }
        }
        if kleur == "orange"
        {
            DispatchQueue.main.async {
                self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
            }
        }
        if kleur == "green"
        {
            DispatchQueue.main.async {
                self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
            }
            
        }
    }
    //Gebruik ik NIET meer want dit was niet performant (voor deze functie heb je internet nodig, voor de manier die ik nu gebruik niet.)
    func haalAchtergrondOp() {
        let url = URL(string: "https://concerttracker.aenterprise.info/session.php")
        
        let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!)
            print("data:")
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any] {
                    print("try")
                    print(json)
                    
                    self.userName = (json["username"] as? String)!
                    print("Username is: \(self.userName)")
                    
                    if (json["Thema"] as? String == "blue")
                    {
                        DispatchQueue.main.async {
                            
                            
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "orange")
                    {
                        DispatchQueue.main.async {
                            
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "green")
                    {
                        DispatchQueue.main.async {
                            
                            
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
                        }
                        
                    }
                    
                }
            } catch let error {
                print(error.localizedDescription)
            }
            
        }
        
        task.resume()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
