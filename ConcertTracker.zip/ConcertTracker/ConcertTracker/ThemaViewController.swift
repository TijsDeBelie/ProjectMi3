//
//  ThemaViewController.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 16/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import UIKit

class ThemaViewController: UIViewController, SSRadioButtonControllerDelegate {
    
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var lblGelukt: UILabel!
    @IBOutlet weak var btnSaveOutlet: UIButton!
    @IBOutlet weak var lblAchtergrond: UILabel!
    
    var geselecteerdeKleur: String = ""
    var username: String = ""
    var userName:String = ""
    let defaults = UserDefaults.standard
    var radioButtonController: SSRadioButtonsController?
    
    //De functie als je een andere radiobutton selecteerd.
    func didSelectButton(selectedButton: UIButton?) {
        NSLog(" \(String(describing: selectedButton))" )
        print("Geselecteerde btn")
        print(radioButtonController!.selectedButton() as Any)
        btnSaveOutlet.isEnabled = true
        btnSaveOutlet.backgroundColor = UIColor(red: 20/255, green: 159/255, blue: 255/255, alpha: 1)
        lblGelukt.text = ""
        if radioButtonController?.selectedButton() == button1 {
            print("Knop 1/Blue")
            geselecteerdeKleur = "blue"
            lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
        }
        if radioButtonController?.selectedButton() == button2 {
            print("Knop 2/Orange")
            geselecteerdeKleur = "orange"
            lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
        }
        if radioButtonController?.selectedButton() == button3 {
            print("Knop 3/Green")
            geselecteerdeKleur = "green"
            lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
        }
    }
    //De functie als je op de knop 'Save' klikt
    @IBAction func btnSave(_ sender: UIButton) {
        if radioButtonController?.selectedButton() == button1 {
            print("Knop 1/Blue")
            geselecteerdeKleur = "blue"
        }
        if radioButtonController?.selectedButton() == button2 {
            print("Knop 2/Orange")
            geselecteerdeKleur = "orange"
        }
        if radioButtonController?.selectedButton() == button3 {
            print("Knop 3/Green")
            geselecteerdeKleur = "green"
        }
        saveThema(kleur: geselecteerdeKleur)
        self.btnSaveOutlet.isEnabled = false
        self.btnSaveOutlet.backgroundColor = UIColor.gray
    }
    
    //Sla de thema kleur op in de database
    func saveThema(kleur: String) {
        let myUrl = URL(string: "https://concerttracker.aenterprise.info/Thema.php");
        
        var request = URLRequest(url:myUrl!)
        
        request.httpMethod = "POST"
        
        print("username\(userName)")

        defaults.setValue(geselecteerdeKleur, forKey: "Thema")
        print("Kleur is: \(geselecteerdeKleur)")
        let Username = defaults.string(forKey: "Username")
        let postString = "user=\(Username!)&value=\(geselecteerdeKleur)"
        print(postString)
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data: Data?, response: URLResponse?, error: Error?) in
            
            if error != nil
            {
                print("error=\(String(describing: error))")
                let alertController = UIAlertController(title: "Concert-Tracker", message:
                    "No internet connection available, please try again", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
                return
            }
            else
            {
                DispatchQueue.main.async {
                    self.lblGelukt.text = "Your account information has been changed succesfully"
                }
                
            }
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                if let parseJSON = json {
                    print(parseJSON)
                    
                }
            } catch let error {
                print("Error: ")
                print(error)
                
            }
        }
        task.resume()
    }
    //Hier haal in de achtergrond kleur op die ik lokaal heb opgeslagen uit de session. En selecteer in deze kleur
    func themaKleur() {
        let kleur = defaults.string(forKey: "Thema")
        print("Userdef kleur is: \(String(describing: kleur))")
        if kleur == "blue"
        {
            DispatchQueue.main.async {
                
                self.button1.isSelected = true
                
                self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
            }
        }
        if kleur == "orange"
        {
            DispatchQueue.main.async {
                
                self.button2.isSelected = true
                self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
            }
        }
        if kleur == "green"
        {
            DispatchQueue.main.async {
                
                self.button3.isSelected = true
                self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
            }
            
        }
    }
    //Gebruik ik NIET meer.
    func haalDataOp() {
        let url = URL(string: "https://concerttracker.aenterprise.info/session.php")
        
        let task = URLSession.shared.dataTask(with: url!) {(data, response, error) in
            print(NSString(data: data!, encoding: String.Encoding.utf8.rawValue)!)
            print("data:")
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? [String: Any] {
                    print("try")
                    print(json)
                    
                    self.userName = (json["username"] as? String)!
                    print("Username is: \(self.userName)")
                    
                    if (json["Thema"] as? String == "blue")
                    {
                        DispatchQueue.main.async {
                            
                            self.button1.isSelected = true
                           
                            self.lblAchtergrond.backgroundColor = UIColor(red: 222/255, green: 242/255, blue: 255/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "orange")
                    {
                        DispatchQueue.main.async {
                            
                            self.button2.isSelected = true
                            self.lblAchtergrond.backgroundColor = UIColor(red: 251/255, green: 241/255, blue: 207/255, alpha: 1)
                        }
                    }
                    if (json["Thema"] as? String == "green")
                    {
                        DispatchQueue.main.async {
                            
                            self.button3.isSelected = true
                            
                            self.lblAchtergrond.backgroundColor = UIColor(red: 221/255, green: 237/255, blue: 226/255, alpha: 1)
                        }
                        
                    }
                    
                }
            } catch let error {
                print(error.localizedDescription)
            }
            
        }
        
        task.resume()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        radioButtonController = SSRadioButtonsController(buttons: button1, button2, button3)
        radioButtonController!.delegate = self
        radioButtonController!.shouldLetDeSelect = true
        //haalDataOp()
        themaKleur()
        self.btnSaveOutlet.isEnabled = false
        self.btnSaveOutlet.backgroundColor = UIColor.gray
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
