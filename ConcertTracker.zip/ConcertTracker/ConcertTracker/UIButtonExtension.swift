//
//  UIButtonExtension.swift
//  ConcertTracker
//
//  Created by Senne Valvekens on 18/12/17.
//  Copyright © 2017 Senne Valvekens. All rights reserved.
//

import Foundation
import UIKit

//OM DE LOGIN KNOP TE ANIMEREN
extension UIButton {
    
    func pulsate() {
        
        let pulse = CASpringAnimation(keyPath: "transform.scale")
        pulse.duration = 1
        pulse.fromValue = 0.95
        pulse.toValue = 1.2
        pulse.autoreverses = true
        pulse.repeatCount = 10000000
        //pulse.initialVelocity = 0.5
        pulse.damping = 1.0
        
        layer.add(pulse, forKey: "pulse")
    }
}
